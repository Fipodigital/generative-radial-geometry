# Toothed Sector (GRG)

This is a simplified toothed sector profile generated with a radial law r(θ) over the angular span [0.0°, 120.0°].
Teeth are modeled as a piecewise-linear “triangular” modulation between root radius Rr=48.0 mm and tip radius Rt=54.0 mm,
with 12 teeth over 120.0°.

## Parameters
- Base radius: 50.0 mm
- Addendum: 4.0 mm
- Dedendum: 2.0 mm
- Sector angle: 120.0°
- Teeth: 12
- Tooth pitch: 10.0°

## Measurements (GRG)
- Perimeter: 279.844195 mm
- Area: 314.263949 mm^2

Note: This is a **didactic radial-tooth profile** (not involute). It is intended to illustrate GRG measurement on a mechanical-like outline.
